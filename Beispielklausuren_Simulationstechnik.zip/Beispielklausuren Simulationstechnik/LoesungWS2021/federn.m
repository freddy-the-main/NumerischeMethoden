function erg = federn (d1, d2, m)
    g = 9.81;   % Erdbeschleunigung
    Vmin = inf; % Vmin mit sehr großem Wert initialisieren
    y1 = -m*g / (d1+d2) - 2; % Untergrenze für y
    ystep = -y1/1000; % Schrittweite für y
    xstep = 2/1000;   % Schrittweite für x
    
    % Schleife über alle x- und y-Werte
    for x = -1.0:xstep:1.0
        for y = y1:ystep:0.0
            % Potential V(x,y) berechnen
            L1 = sqrt ((x+1)^2 + y^2);
            L2 = sqrt ((x-1)^2 + y^2);
            V = 0.5 * d1 * (L1-1)^2 + 0.5 * d2 * (L2-1)^2 + m * g * y;
            
            % Minimum merken
            if V < Vmin
                Vmin = V;
                xmin = x;
                ymin = y;
            end
        end
    end
    erg = [xmin, ymin, Vmin]; % Rückgabe
    
    % Erweiterung: Plotten
    plot ([-1.2 1.2], [0 0], 'b-');        % Decke plotten
    hold on;
    plot ([-1 xmin 1], [0 ymin 0], 'ro-'); % Federn plotten
    axis equal; % gleicher Maßstab für x und y
end
