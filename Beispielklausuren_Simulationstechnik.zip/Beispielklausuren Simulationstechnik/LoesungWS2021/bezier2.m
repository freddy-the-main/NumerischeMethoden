function bezier2 (x0, x1, x2, y0, y1, y2)
    t = 0:0.01:1;
    x = (1-t).^2 * x0 + 2 * (1-t).*t * x1 + t.^2 * x2;
    y = (1-t).^2 * y0 + 2 * (1-t).*t * y1 + t.^2 * y2;
    
    plot(x, y);
    axis equal;
    title('Bézier-Kurve 2. Ordnung');
end
