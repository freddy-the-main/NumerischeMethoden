function erg = fermat (n, x3, y1, y2, y3)
    step = x3/1000;
    mintime = inf; % oder: sqrt (x3^2 + y3^2) * (n+1);
    
    for x1 = 0:step:x3
        for x2 = 0:step:x3
            % Berechnung der Laufzeit time
            time = sqrt (x1^2 + y1^2) ...                   % Luft
                 + sqrt ((x2 - x1)^2 + (y2 - y1)^2) * n ... % Glas
                 + sqrt ((x3 - x2)^2 + (y3 - y2)^2);        % Luft
             
            % Falls kleiner Laufzeit gefunden -> Werte merken
            if time < mintime
                mintime = time;
                x1min = x1;
                x2min = x2;
            end
        end
    end
    
    % Rückgabewert zuweisen
    erg = [x1min, x2min, mintime];
    
    % Erweiterung: Plotten
    plot ([0 x1min x2min x3], [0 y1 y2 y3], 'r-');
    hold on;
    plot ([0 x3], [y1 y1], 'b-');
    plot ([0 x3], [y2 y2], 'b-');
    axis equal;
end
