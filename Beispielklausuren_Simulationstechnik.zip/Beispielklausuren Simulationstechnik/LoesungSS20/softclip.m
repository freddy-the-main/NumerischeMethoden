function softclip (grenze, freq)
    t = 0:0.01:10;
    input = t .* sin (freq * t);
    output = grenze * 2/pi * atan (input / grenze * pi/2);
    
    plot (t, output);
    title ('Soft Clipping');
end